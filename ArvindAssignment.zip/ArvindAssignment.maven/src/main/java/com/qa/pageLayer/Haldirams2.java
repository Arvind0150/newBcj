package com.qa.pageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.testBase.TestBase;

public class Haldirams2 extends TestBase {
	
	public Haldirams2()
	{
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="(//select[@id=\"sorter\"])[1]")
	private WebElement sorter1;
	public void selectDropdown1()
	{
		
		Select s = new Select(sorter1);
		s.selectByIndex(2);
	}
	
	@FindBy(xpath="(//a[@title=\"Set Descending Direction\"])[1]")
	private WebElement descend1;
	public void clickForDescend1()
	{
		descend1.click();
	}

	@FindBy(xpath="(//a[@title=\"Set Ascending Direction\"])[1]")
	private WebElement ascend1;
	public void clickForAscend1()
	{
		ascend1.click();
	}
	


}
