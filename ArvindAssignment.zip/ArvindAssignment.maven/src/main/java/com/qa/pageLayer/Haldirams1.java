package com.qa.pageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.testBase.TestBase;

public class Haldirams1 extends TestBase {
	
	public Haldirams1()
	{
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="(//select[@id=\"sorter\"])[1]")
	private WebElement sorter;
	public void selectDropdown()
	{
		
		Select s = new Select(sorter);
		s.selectByIndex(1);
	}
	
	@FindBy(xpath="(//a[@title=\"Set Descending Direction\"])[1]")
	private WebElement descend;
	public void clickForDescend()
	{
		descend.click();
	}

	@FindBy(xpath="(//a[@title=\"Set Ascending Direction\"])[1]")
	private WebElement ascend;
	public void clickForAscend()
	{
		ascend.click();
	}
	

}
