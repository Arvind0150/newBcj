package com.qa.testLayer;

import org.testng.annotations.Test;

import com.qa.testBase.TestBase;

public class Haldirams2Test extends TestBase{
	
	@Test
	public void verifyHaldirams1() throws InterruptedException
	{
		Haldi2.selectDropdown1();
		logger.info("Selected dropdown and selected Price Option successfully");
		Thread.sleep(1000);
		Haldi2.clickForDescend1();
		logger.info("Clicked for showing descending  order of Price successfully");
		Haldi2.clickForAscend1();
		logger.info("Clicked for showing ascending  order of Price successfully");
		
	}


}
