package com.qa.testLayer;

import org.testng.annotations.Test;

import com.qa.testBase.TestBase;

public class Haldirams1Test extends TestBase{
	
	@Test
	public void verifyHaldirams1() throws InterruptedException
	{
		Haldi1.selectDropdown();
		logger.info("Selected dropdown and selected Product Name Option successfully");
		Thread.sleep(1000);
		Haldi1.clickForDescend();
		logger.info("Clicked for showing descending alphabetical order of Product Names successfully");
		Haldi1.clickForAscend();
		logger.info("Clicked for showing ascending alphabetical order of Product Names successfully");
	}

	

	}


